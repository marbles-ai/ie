from __future__ import unicode_literals, print_function
import os

DATA_PATH=os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
